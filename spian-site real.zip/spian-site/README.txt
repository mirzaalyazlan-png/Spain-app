SPIAN - put this folder online once, then updates are one drag-and-drop.

FIRST TIME (Netlify, free):
1. Go to app.netlify.com/drop and drag this whole folder onto the page.
2. You get a link like https://something.netlify.app . Send that link to everyone (phones and PCs).

EVERY UPDATE:
1. In Netlify open your site, go to Deploys, and drag the new folder onto the "Drag and drop" area.
2. That is all. Nobody needs a new file. People who already have Spian open see
   "A new version of Spian is ready" and press Reload (their servers, profile and friends are kept).

GitHub Pages also works: upload index.html to a repository and turn on Pages.
